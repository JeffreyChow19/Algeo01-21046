# This is Primitives Folder

dir : `src/codes/ADT/primitives`

Contains :
1. `CheckNeg0.java` 
2. `GetCofactor.java` 
3. `MakeSquare.java`
4. `SwitchCol.java`
5. `IsSquare.java` 
6. `TimesDiagonal.java` 
7. `Transpose.java` 
8. `CopyMtrx.java` 

