# This is `Abstract Data Type` Folder

dir : `src/codes/ADT`

Contains :
1. `Matrix.java`
2. `Param.java`
3. `constructors` folder
4. `primitives` folder
