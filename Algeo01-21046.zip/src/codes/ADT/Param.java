package codes.ADT;

public class Param {
    public double val;
    public char[] params;
    public double[] valPar;

    public Param(double val, char[] params, double[] valPar) {
        this.val = val;
        this.params = params;
        this.valPar = valPar;
    }
}
