# This is Constructor Folder

dir : `src/codes/ADT/constructor`

1. `createMtrx.java`
2. `createMtrxConsole.java`
3. `createMtrxFile`
4. `printMtrx.java`
5. `printMtrxConsole.java`
6. `printMtrxFile.java`