# This is `Inputs` Folder

dir : `src/codes/inputs`

Contains:
1. `inputSPL.java`
2. `inputDeterminan.java`
3. `inputInvers.java`
4. `inputPolynom.java`
5. `inputBikubik.java`

