# This is `codes` Folder

dir : `src/codes`

Contains :
1. `ADT` folder
2. `inputs` folder
3. `methods` folder
4. `mainProgram.java`


