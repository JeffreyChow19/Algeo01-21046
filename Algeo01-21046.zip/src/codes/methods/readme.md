# This is `Methods` Folder

dir : `src/codes/methods`

Contains:
1. `Cramer.java`
2. `Gauss.java`
3. `GaussJordan.java`
4. `determinant.java`
5. `InverseCofactor.java`
6. `InverseGaussJordan.java`
7. `InterpolasiBicubic.java`
8. `InterpolasiPolinom.java`
9. `RegresiLinierBerganda.java`