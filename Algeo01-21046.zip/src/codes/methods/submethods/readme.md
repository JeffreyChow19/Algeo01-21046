# This is `SubMethods` Folder

dir : `src/codes/methods/submethods`

Contains : 
1. `menuCheck.java`
2. `SPLCheck.java`